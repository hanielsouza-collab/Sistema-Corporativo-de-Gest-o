const API = "http://localhost:3000/api/colaboradores"

async function carregar() {
const resposta = await fetch(API)
const dados = await resposta.json()

const lista = document.getElementById("lista")
lista.innerHTML = ""

dados.forEach((c) => {
    lista.innerHTML += `
        <div class="card">
            <h3>${c.nome_completo}</h3>
            <p>${c.cargo}</p>
            <p>R$ ${c.salario}</p>
        </div>
    `
})

}

document.getElementById("form").addEventListener("submit", async (e) => {
e.preventDefault()

await fetch(API, {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        nome_completo: document.getElementById("nome").value,
        idade: document.getElementById("idade").value,
        cargo: document.getElementById("cargo").value,
        salario: document.getElementById("salario").value,
        tempo_empresa: "Novo",
        data_admissao: "2026-06-17",
        setor: "TI",
        status: "Ativo"
    })
})

carregar()

})

carregar()
