const express = require("express")
const cors = require("cors")
const rotas = require("./src/routes/colaboradorRoutes.js")

const app = express()

app.use(cors())
app.use(express.json())

app.use("/api", rotas)

app.listen(3000, () => {
console.log("Servidor rodando em http://localhost:3000")
})
