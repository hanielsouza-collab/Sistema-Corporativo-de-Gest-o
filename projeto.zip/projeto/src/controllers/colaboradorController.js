const db = require("../database/db")

const listarColaboradores = (req, res) => {
const sql = "SELECT * FROM colaboradores"

db.query(sql, (erro, resultado) => {
    if (erro) {
        res.status(500).json(erro)
        return
    }

    res.json(resultado)
})

}

const criarColaborador = (req, res) => {
const {
nome_completo,
idade,
cargo,
salario,
tempo_empresa,
data_admissao,
setor,
status
} = req.body

const sql = `
    INSERT INTO colaboradores
    (nome_completo, idade, cargo, salario, tempo_empresa, data_admissao, setor, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`

db.query(
    sql,
    [nome_completo, idade, cargo, salario, tempo_empresa, data_admissao, setor, status],
    (erro) => {
        if (erro) {
            res.status(500).json(erro)
            return
        }

        res.json({ mensagem: "Colaborador cadastrado" })
    }
)

}

const atualizarColaborador = (req, res) => {
const { id } = req.params
const { cargo, salario, status } = req.body

const sql = `
    UPDATE colaboradores
    SET cargo = ?, salario = ?, status = ?
    WHERE id = ?
`

db.query(sql, [cargo, salario, status, id], (erro) => {
    if (erro) {
        res.status(500).json(erro)
        return
    }

    res.json({ mensagem: "Colaborador atualizado" })
})

}

const deletarColaborador = (req, res) => {
const { id } = req.params


const sql = "DELETE FROM colaboradores WHERE id = ?"

db.query(sql, [id], (erro) => {
    if (erro) {
        res.status(500).json(erro)
        return
    }

    res.json({ mensagem: "Colaborador removido" })
})

}

module.exports = {
listarColaboradores,
criarColaborador,
atualizarColaborador,
deletarColaborador
}
