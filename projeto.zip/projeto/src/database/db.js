const mysql = require("mysql2")

const db = mysql.createConnection({
host: "localhost",
user: "root",
password: "1234",
database: "empresa"
})

db.connect((erro) => {
if (erro) {
console.log("Erro ao conectar:", erro)
return
}


console.log("Banco conectado com sucesso")


})

module.exports = db
