const express = require("express")
const router = express.Router()

const {
listarColaboradores,
criarColaborador,
atualizarColaborador,
deletarColaborador
} = require("../controllers/colaboradorController")

router.get("/colaboradores", listarColaboradores)
router.post("/colaboradores", criarColaborador)
router.put("/colaboradores/:id", atualizarColaborador)
router.delete("/colaboradores/:id", deletarColaborador)

module.exports = router
