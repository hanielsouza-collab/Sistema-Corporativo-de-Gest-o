CREATE DATABASE empresa;
USE empresa;

CREATE TABLE colaboradores (
id INT AUTO_INCREMENT PRIMARY KEY,
nome_completo VARCHAR(100) NOT NULL,
idade INT NOT NULL,
cargo VARCHAR(50) NOT NULL,
salario DECIMAL(10,2) NOT NULL,
tempo_empresa VARCHAR(30) NOT NULL,
data_admissao DATE NOT NULL,
setor VARCHAR(50) NOT NULL,
status VARCHAR(20) NOT NULL
);

INSERT INTO colaboradores
(nome_completo, idade, cargo, salario, tempo_empresa, data_admissao, setor, status)
VALUES
('Carlos Silva', 29, 'Analista', 3500.00, '2 anos', '2024-01-10', 'TI', 'Ativo'),
('Mariana Souza', 31, 'Gerente', 6200.00, '5 anos', '2021-06-15', 'Financeiro', 'Ativo'),
('Lucas Santos', 25, 'Auxiliar', 1800.00, '1 ano', '2025-02-20', 'RH', 'Ativo'),
('Fernanda Lima', 40, 'Coordenadora', 5500.00, '7 anos', '2019-03-12', 'Marketing', 'Ativo'),
('João Pedro', 27, 'Desenvolvedor', 4200.00, '3 anos', '2023-05-08', 'TI', 'Ativo'),
('Ana Costa', 34, 'Supervisora', 4800.00, '4 anos', '2022-09-11', 'Comercial', 'Ativo'),
('Ricardo Alves', 38, 'Contador', 5100.00, '6 anos', '2020-04-30', 'Financeiro', 'Ativo'),
('Beatriz Rocha', 23, 'Estagiária', 1200.00, '6 meses', '2026-01-05', 'TI', 'Ativo'),
('Gabriel Mendes', 30, 'Assistente', 2500.00, '2 anos', '2024-07-18', 'Logística', 'Inativo'),
('Juliana Pereira', 28, 'Designer', 3900.00, '3 anos', '2023-08-21', 'Marketing', 'Ativo');

SELECT * FROM colaboradores;